package patronesdediseño.AbstractFactory;

public interface IAuto {
    
    String getNombre();

    double getPrecio();    
    
}
