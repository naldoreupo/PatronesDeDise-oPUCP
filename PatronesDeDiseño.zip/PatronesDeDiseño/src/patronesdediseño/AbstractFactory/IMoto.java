package patronesdediseño.AbstractFactory;

public interface IMoto {
    
    String getNombre();

    double getPrecio();    
    
}
