package patronesdediseño.AbstractFactory;

public interface IBus {
    
    String getNombre();

    double getPrecio();    
    
}
