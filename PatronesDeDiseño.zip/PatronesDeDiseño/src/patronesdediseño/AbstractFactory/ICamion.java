package patronesdediseño.AbstractFactory;

public interface ICamion {
    
    String getNombre();

    double getPrecio();    
    
}
